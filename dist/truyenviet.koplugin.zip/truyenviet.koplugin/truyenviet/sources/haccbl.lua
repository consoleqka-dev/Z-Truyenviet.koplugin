local Http = require("truyenviet/http_client")
local Util = require("truyenviet/helpers")
local ko_util = require("util")
local ok_json, json = pcall(require, "json")
if not ok_json or not json then
    ok_json, json = pcall(require, "dkjson")
end

local Source = {
    id = "haccbl",
    name = "Hắc Ám Chi Các",
    kind = "comic",
    base_url = "https://haccbl.xyz",
    reversed_chapters = true,
}

local function requestHeaders()
    return {
        ["Referer"] = Source.base_url .. "/",
    }
end

function Source:getCoverHeaders()
    return requestHeaders()
end

local function cleanTitle(value)
    value = Util.stripTags(value)
    value = value:gsub("%s+", " ")
    return Util.trim(value)
end

local function addStory(stories, href, title, cover_url)
    title = cleanTitle(title)
    if not href or title == "" then
        return
    end
    table.insert(stories, {
        source_id = Source.id,
        title = title,
        url = Util.absoluteUrl(Source.base_url, href),
        cover_url = Util.absoluteUrl(Source.base_url, cover_url),
        kind = Source.kind,
    })
end

-- Ảnh bìa haccbl thường là AVIF (KOReader không hỗ trợ).
-- Ưu tiên lấy URL .webp từ srcset nếu có.
local function pickCoverUrl(image_tag)
    if not image_tag then return nil end
    local final_url = nil
    local srcset = Util.getAttribute(image_tag, "srcset")
    if srcset then
        local best_url, best_w = nil, 0
        for url, w in srcset:gmatch("(%S+)%s+(%d+)w") do
            local nw = tonumber(w) or 0
            if url:find("%.webp", 1, true) and nw > best_w then
                best_url, best_w = url, nw
            end
        end
        if best_url then final_url = best_url end
        if not final_url then
            for url, w in srcset:gmatch("(%S+)%s+(%d+)w") do
                local nw = tonumber(w) or 0
                if nw > best_w then
                    best_url, best_w = url, nw
                end
            end
            if best_url then final_url = best_url end
        end
    end
    if not final_url then
        final_url = Util.getAttribute(image_tag, "src") or Util.getAttribute(image_tag, "data-src")
    end
    if final_url then
        final_url = Util.absoluteUrl(Source.base_url, final_url)
        if final_url:find(".avif", 1, true) then
            final_url = final_url:gsub("^https?://", "https://i0.wp.com/") .. "?strip=info&format=webp"
        end
    end
    return final_url
end

function Source:parseSearch(html)
    local stories = {}

    for block in html:gmatch('<div[^>]-class="[^"]*manga%-item%-grid[^"]*"[^>]*>([%s%S]-)</h2>') do
        local href = block:match('<a href="([^"]+)"')
        local image_tag = block:match("(<img[^>]*>)")
        local img = pickCoverUrl(image_tag)
        local title = block:match('<a[^>]-class="[^"]*uk%-link%-heading[^"]*"[^>]*>([%s%S]-)$')
        addStory(stories, href, title, img)
    end

    for item_html in html:gmatch('<article[^>]*>([%s%S]-)</article>') do
        local title_html = item_html:match('<h2[^>]*>([%s%S]-)</h2>')
            or item_html:match('<h3[^>]*>([%s%S]-)</h3>')
        local anchor = title_html and title_html:match("(<a[^>]*>)")
        local href = Util.getAttribute(anchor, "href")
        local image_tag = item_html:match("(<img[^>]*>)")
        if href and href:find("/manga/", 1, true) then
            addStory(stories, href, title_html, pickCoverUrl(image_tag))
        end
    end

    return Util.uniqueBy(stories, "url")
end

-- Tìm kiếm `/?s=` không còn trả kết quả; site dùng REST live-search của theme.
-- Trả mảng JSON {title (có <mark>), url, post_type, thumb}; chỉ lấy post_type "manga".
function Source:search(query)
    local url = self.base_url .. "/wp-json/initlise/v1/search?term=" .. ko_util.urlEncode(query)
    local body, err = Http:getJson(url, requestHeaders())
    if not body then
        return nil, err
    end
    if not ok_json or not json then
        return nil, "Thiếu thư viện JSON"
    end
    local ok, data = pcall(json.decode, body)
    if not ok or type(data) ~= "table" then
        return nil, "Phản hồi tìm kiếm không hợp lệ"
    end

    local stories = {}
    for _, item in ipairs(data) do
        if type(item) == "table" and item.post_type == "manga"
                and type(item.url) == "string" and type(item.title) == "string" then
            local cover_url = type(item.thumb) == "string" and item.thumb or nil
            -- KOReader không đọc được AVIF: đổi sang WEBP qua proxy như pickCoverUrl
            if cover_url and cover_url:find(".avif", 1, true) then
                cover_url = cover_url:gsub("^https?://", "https://i0.wp.com/") .. "?strip=info&format=webp"
            end
            addStory(stories, item.url, item.title, cover_url)
        end
    end
    return Util.uniqueBy(stories, "url")
end

-- Chương mới nhất: JSON-LD `hasPart` chỉ liệt kê 3 chương mới nhất, mỗi chương có
-- `"issueNumber":10` hoặc `"issueNumber":83.3` (chương phụ/extra mang số thập phân).
-- Lấy số lớn nhất thay vì phần tử đầu. Nếu thiếu JSON-LD thì suy từ href của danh sách chương
-- (`chapter-83-3/` -> 83.3, `chapter-10/` -> 10).
local function parseLatestChapter(html)
    local best
    local function consider(n)
        if n and n > 0 and (not best or n > best) then best = n end
    end
    for value in html:gmatch('"issueNumber"%s*:%s*"?(%d+%.?%d*)"?') do
        consider(tonumber(value))
    end
    if best then return best end
    for whole, frac in html:gmatch('<div class="chapter%-item">%s*<a[^>]-href="[^"]-/chapter%-(%d+)%-?(%d*)/"') do
        consider(tonumber(frac ~= "" and (whole .. "." .. frac) or whole))
    end
    return best
end

-- Số chương + trạng thái chính xác từ JSON-LD của trang truyện (1 request).
function Source:fetchSearchMeta(story)
    local html, err = Http:get(story.url, requestHeaders())
    if not html then
        return nil, err
    end

    local meta = {}
    local count = tonumber(html:match('"name":"chapterCount","value":"(%d+)"'))
    if count and count > 0 then
        meta.chapter_count = count
    end
    local status = html:match('"name":"status","value":"(%a+)"')
    if status then
        meta.completed = status:lower() == "completed"
    end
    meta.latest_chapter = parseLatestChapter(html)
    if meta.chapter_count == nil and meta.completed == nil and meta.latest_chapter == nil then
        return nil, "Không đọc được số chương"
    end
    return meta
end

local function parseGenreLinks(html)
    local genres = {}
    local seen = {}

    -- Khối menu/sidebar thể loại thường nằm trong <ul>/<div> có class/id chứa "genre"
    local container = html:match('<ul[^>]-class="[^"]*genres[^"]*"[^>]*>([%s%S]-)</ul>')
        or html:match('<div[^>]-class="[^"]*genres[^"]*"[^>]*>([%s%S]-)</div>')
        or html:match('<ul[^>]-id="genre%-list"[^>]*>([%s%S]-)</ul>')
        or html:match('<div[^>]-id="genre%-list"[^>]*>([%s%S]-)</div>')

    local scope = container or html

    for href, label in scope:gmatch('<a[^>]-href="([^"]+)"[^>]*>([%s%S]-)</a>') do
        local lower_href = href:lower()
        if lower_href:find("/genre/", 1, true)
                or lower_href:find("/genres/", 1, true)
                or lower_href:find("/the%-loai/") then
            local name = Util.stripTags(label):gsub("^%s*", ""):gsub("%s*$", "")
            if name ~= "" and not seen[href] then
                seen[href] = true
                table.insert(genres, {
                    name = name,
                    url = Util.absoluteUrl(Source.base_url, href),
                })
            end
        end
    end

    return genres
end

function Source:parseListing(html, page)
    local stories = self:parseSearch(html)
    local genres = parseGenreLinks(html)

    local max_page = page or 1
    for p_num in html:gmatch('page/(%d+)/"') do
        local n = tonumber(p_num)
        if n and n > max_page then
            max_page = n
        end
    end

    return {
        stories = stories,
        genres = genres,
        page = page or 1,
        total_pages = max_page,
    }
end

function Source:getCompleted(page)
    page = page or 1
    local url = self.base_url .. "/truyen-da-hoan-thanh/"
    if page > 1 then
        url = url .. "page/" .. page .. "/"
    end
    local html, err = Http:get(url, requestHeaders())
    if not html then
        return nil, err
    end
    local result = self:parseListing(html, page)
    result.title = "Truyện đã hoàn thành"
    return result
end

function Source:getGenre(genre, page)
    page = page or 1
    local url = genre.url:gsub("/+$", "")
    if page > 1 then
        url = url .. "/page/" .. page .. "/"
    end
    local html, err = Http:get(url, requestHeaders())
    if not html then
        return nil, err
    end
    local result = self:parseListing(html, page)
    result.title = genre.name
    result.genre = genre
    return result
end

function Source:parseStoryDetails(html)
    local description_html = html:match(
        '<div[^>]-class="[^"]*story%-content[^"]*"[^>]*>([%s%S]-)</div>'
    ) or html:match('<div[^>]-class="[^"]*entry%-content[^"]*"[^>]*>([%s%S]-)</div>')
    
    local author = html:match('Tác giả:[%s%S]-<a[^>]*>([%s%S]-)</a>')
        or html:match('<a[^>]-href="[^"]*/author/[^"]*"[^>]*>.-<span[^>]*>([%s%S]-)</span>')
    if author then author = Util.stripTags(author) end
    
    local status = html:match('Tình trạng:[%s%S]-<span[^>]*>([%s%S]-)</span>')
    if status then status = Util.stripTags(status) end

    local genre_html = html:match('<div[^>]-id="genre%-tags"[^>]*>([%s%S]-)</div>')
        or html:match('<div[^>]-class="[^"]*genres[^"]*"[^>]*>([%s%S]-)</div>')
    local genres = {}
    if genre_html then
        for anchor_html in genre_html:gmatch("<a[^>]*>([%s%S]-)</a>") do
            local clean_genre = Util.stripTags(anchor_html):gsub("^%s*", ""):gsub("%s*$", "")
            table.insert(genres, clean_genre)
        end
    end
    
    local cover_url = html:match('<meta property="og:image" content="([^"]+)"')
    -- Dùng proxy i0.wp.com để chuyển AVIF sang WEBP
    if cover_url and cover_url:find(".avif", 1, true) then
        cover_url = cover_url:gsub("^https?://", "https://i0.wp.com/") .. "?strip=info&format=webp"
    end

    return {
        description = Util.stripTags(description_html)
            ~= "" and Util.stripTags(description_html)
            or Util.getMetaContent(html, "name", "description"),
        author = author,
        status = status,
        genres = genres,
        cover_url = cover_url,
    }
end

function Source:getStoryDetails(story)
    local html, err = Http:get(story.url, requestHeaders())
    if not html then
        return nil, err
    end
    local details = self:parseStoryDetails(html)
    if details.cover_url then
        story.cover_url = details.cover_url
    end
    return details
end

function Source:parseStoryPage(html, story, page)
    local chapters = {}
    
    -- Parse init-manga style chapter items directly from HTML
    for item_html in html:gmatch('<div[^>]-class="[^"]*chapter%-item[^"]*"[^>]*>([%s%S]-)</div>') do
        local href = item_html:match('href="([^"]+)"')
        local title = item_html:match('<span[^>]-class="[^"]*chapter%-name[^"]*"[^>]*>([%s%S]-)</span>')
            or item_html:match('<h3[^>]*>([%s%S]-)</h3>')
            or (href and href:match("chapter%-([%d%.]+)") and ("Chapter " .. href:match("chapter%-([%d%.]+)")))
            or "Chapter"
        
        if href and (href:find("chapter") or href:find("chuong")) then
            table.insert(chapters, {
                title = Util.stripTags(title):gsub("^%s*", ""):gsub("%s*$", ""),
                url = Util.absoluteUrl(self.base_url, href),
                source_id = self.id,
                story_url = story.url,
                kind = self.kind,
            })
        end
    end

    -- Fallback: find anchors directly inside chapter-list (now searching entire html)
    if #chapters == 0 then
        for anchor_attrs, anchor_html in html:gmatch("<a([^>]*)>([%s%S]-)</a>") do
            local href = Util.getAttribute(anchor_attrs, "href")
            if href and (href:find("/chapter") or href:find("/chuong")) and not href:find("#") then
                local title = anchor_html:match(
                    '<h3[^>]*>([%s%S]-)</h3>'
                ) or anchor_html
                table.insert(chapters, {
                    title = Util.stripTags(title):gsub("^%s*", ""):gsub("%s*$", ""),
                    url = Util.absoluteUrl(self.base_url, href),
                    source_id = self.id,
                    story_url = story.url,
                    kind = self.kind,
                })
            end
        end
    end

    -- Final fallback: search entire page for chapter links
    if #chapters == 0 then
        for anchor_attrs, anchor_html in html:gmatch("<a([^>]*)>([%s%S]-)</a>") do
            local href = Util.getAttribute(anchor_attrs, "href")
            local class_attr = Util.getAttribute(anchor_attrs, "class") or ""
            if href and (href:find("/chapter") or class_attr:find("chapter")) and not href:find("#") then
                local title = anchor_html:match(
                    '<h3[^>]-class="[^"]*uk%-link%-heading[^"]*"[^>]*>([%s%S]-)</h3>'
                ) or anchor_html
                local chapter_url = Util.absoluteUrl(self.base_url, href)
                table.insert(chapters, {
                    title = Util.stripTags(title):gsub("^%s*", ""):gsub("%s*$", ""),
                    url = chapter_url,
                    source_id = self.id,
                    story_url = story.url,
                    kind = self.kind,
                })
            end
        end
    end

    local total_pages = Util.maxPage(html, 1)

    story.details = self:parseStoryDetails(html)
    return {
        story = story,
        chapters = Util.uniqueBy(chapters, "url"),
        page = page or 1,
        total_pages = total_pages,
    }
end

function Source:getStoryPage(story, page)
    page = page or 1
    local url = story.url
    if page > 1 then
        url = Util.withTrailingSlash(url) .. "chapter/page/" .. page .. "/"
    end
    local html, err = Http:get(url, requestHeaders())
    if not html then
        return nil, err
    end
    return self:parseStoryPage(html, story, page)
end

function Source:parseChapter(html, chapter)
    local images = {}

    local content = html:match(
        '<div[^>]-id="chapter%-content"[^>]*>([%s%S]-)</div>%s*<div[^>]-class="[^"]*init%-ad after%-content'
    ) or html:match('<div[^>]-id="chapter%-content"[^>]*>([%s%S]-)</div>') or html

    if content:find("InitMangaEncryptedChapter", 1, true) then
        local keyStrBase64 = html:match('"decryption_key"%s*:%s*"([^"]+)"')
        local ciphertext = content:match('"ciphertext"%s*:%s*"([^"]+)"')
        local ivHex = content:match('"iv"%s*:%s*"([^"]+)"')
        local saltHex = content:match('"salt"%s*:%s*"([^"]+)"')

        if keyStrBase64 and ciphertext and ivHex and saltHex then
            local Debug = require("truyenviet/debugger")
            Debug.write("[haccbl] InitMangaEncryptedChapter match: " .. keyStrBase64)
            local status, ffi = pcall(require, "ffi")
            if status and ffi then
                Debug.write("[haccbl] ffi loaded successfully")
                local function safe_cdef(decl)
                    local ok, err = pcall(function() ffi.cdef(decl) end)
                    if not ok then
                        Debug.write("[haccbl] safe_cdef failed: " .. tostring(err) .. " for: " .. decl)
                    end
                end
                safe_cdef("typedef struct evp_md_st EVP_MD;")
                safe_cdef("typedef struct evp_cipher_st EVP_CIPHER;")
                safe_cdef("const EVP_MD *EVP_sha512(void);")
                safe_cdef([[
                    int PKCS5_PBKDF2_HMAC(const char *pass, int passlen,
                                          const unsigned char *salt, int saltlen, int iter,
                                          const EVP_MD *digest,
                                          int keylen, unsigned char *out);
                ]])
                safe_cdef([[
                    unsigned char *HMAC(const EVP_MD *evp_md, const void *key, int key_len,
                                        const unsigned char *d, unsigned long n, unsigned char *md,
                                        unsigned int *md_len);
                ]])
                safe_cdef("const EVP_CIPHER *EVP_aes_256_cbc(void);")
                safe_cdef("typedef struct evp_cipher_ctx_st EVP_CIPHER_CTX;")
                safe_cdef("EVP_CIPHER_CTX *EVP_CIPHER_CTX_new(void);")
                safe_cdef("void EVP_CIPHER_CTX_free(EVP_CIPHER_CTX *c);")
                safe_cdef([[
                    int EVP_DecryptInit_ex(EVP_CIPHER_CTX *ctx, const EVP_CIPHER *cipher, void *impl,
                                           const unsigned char *key, const unsigned char *iv);
                ]])
                safe_cdef([[
                    int EVP_DecryptUpdate(EVP_CIPHER_CTX *ctx, unsigned char *out, int *outl,
                                          const unsigned char *in_buf, int inl);
                ]])
                safe_cdef("int EVP_DecryptFinal_ex(EVP_CIPHER_CTX *ctx, unsigned char *outm, int *outl);")
                local crypto_status, libcrypto
                local lib_names = {
                    "crypto",
                    "libcrypto",
                    "libcrypto.so",
                    "libcrypto.so.3",
                    "libcrypto.so.1.1",
                    "libcrypto.so.1.0.0",
                    "libcrypto.so.56",
                    "libcrypto.so.55",
                    "libcrypto.so.48",
                    "libcrypto.so.47",
                    "libcrypto.so.46",
                    "libcrypto.so.45",
                    "libcrypto.so.44",
                    "libcrypto.so.43",
                    "libcrypto.so.42",
                    "libcrypto.so.41",
                    "libcrypto.so.39",
                    "libcrypto.so.38",
                    "libcrypto.so.37",
                    "libcrypto.so.35",
                    "libcrypto.so.1.0.2",
                    "libcrypto.so.1.0.1",
                    "libs/libcrypto.so",
                    "libs/libcrypto.so.3",
                    "libs/libcrypto.so.1.1",
                    "libs/libcrypto.so.56",
                    "libs/libcrypto.so.55",
                    "libs/libcrypto.so.1.0.0",
                    "libs/libcrypto-3-x64.dll",
                    "libs/libcrypto-1_1-x64.dll",
                    "libcrypto-3-x64",
                    "libcrypto-1_1-x64",
                    "libcrypto-3",
                    "libcrypto-1_1",
                    "crypto-3",
                    "crypto-1_1",
                    "libcrypto-3.dll",
                    "libcrypto-1_1.dll",
                    "ssl",
                    "libssl",
                    "libssl.so",
                    "libs/libssl.so",
                }
                local ok_req_crypto, req_crypto = pcall(require, "crypto")
                if ok_req_crypto and type(req_crypto) == "table" then
                    local keys = {}
                    for k, v in pairs(req_crypto) do table.insert(keys, tostring(k)) end
                    Debug.write("[haccbl] require('crypto') found. Keys: " .. table.concat(keys, ", "))
                else
                    Debug.write("[haccbl] require('crypto') NOT found or not a table: " .. tostring(req_crypto))
                end

                local ok_ffi_c, err_ffi_c = pcall(function() return ffi.C.EVP_sha512 end)
                Debug.write("[haccbl] ffi.C.EVP_sha512 available? " .. tostring(ok_ffi_c) .. " err: " .. tostring(err_ffi_c))

                for _, name in ipairs(lib_names) do
                    local loaded_via = nil
                    crypto_status, libcrypto = pcall(ffi.load, name)
                    if crypto_status and libcrypto then
                        loaded_via = "load"
                    else
                        if ffi.loadlib then
                            crypto_status, libcrypto = pcall(ffi.loadlib, name)
                            if crypto_status and libcrypto then
                                loaded_via = "loadlib"
                            end
                        end
                    end
                    
                    if loaded_via then
                        local ok_sha, err_sha = pcall(function() return libcrypto.EVP_sha512 end)
                        local ok_hmac, err_hmac = pcall(function() return libcrypto.HMAC end)
                        local ok_pb, err_pb = pcall(function() return libcrypto.PKCS5_PBKDF2_HMAC end)
                        Debug.write(string.format("[haccbl] Loaded %s via %s: type=%s, EVP_sha512=%s (%s), HMAC=%s (%s), PKCS5_PBKDF2_HMAC=%s (%s)",
                            name, loaded_via, type(libcrypto),
                            tostring(ok_sha), tostring(err_sha),
                            tostring(ok_hmac), tostring(err_hmac),
                            tostring(ok_pb), tostring(err_pb)
                        ))
                        
                        local has_min_symbols = (ok_sha and ok_hmac) or ok_pb
                        if has_min_symbols then
                            break
                        else
                            libcrypto = nil
                            crypto_status = false
                        end
                    end
                end
                local function hex2bin(hexstr)
                    return (hexstr:gsub('..', function(cc)
                        return string.char(tonumber(cc, 16))
                    end))
                end

                local function base64_decode(data)
                    local b = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
                    data = string.gsub(data, '[^'..b..'=]', '')
                    return (data:gsub('.', function(x)
                        if (x == '=') then return '' end
                        local r,f='',(b:find(x)-1)
                        for i=6,1,-1 do r=r..(f%2^i-f%2^(i-1)>0 and '1' or '0') end
                        return r;
                    end):gsub('%d%d%d?%d?%d?%d?%d?%d?', function(x)
                        if (#x ~= 8) then return '' end
                        local c=0
                        for i=1,8 do c=c+(x:sub(i,i)=='1' and 2^(8-i) or 0) end
                        return string.char(c)
                    end))
                end

                local keyStr = base64_decode(keyStrBase64)
                local salt = hex2bin(saltHex)
                local iv = hex2bin(ivHex)
                local cipherbin = base64_decode(ciphertext)
                local decrypt_ok = false

                if crypto_status and libcrypto then
                    Debug.write("[haccbl] Using libcrypto pointer: " .. tostring(libcrypto))
                    local derivedKey
                    local has_pbkdf2, err_pbkdf2 = pcall(function() return libcrypto.PKCS5_PBKDF2_HMAC end)
                    if has_pbkdf2 then
                        derivedKey = ffi.new("unsigned char[32]")
                        local res = libcrypto.PKCS5_PBKDF2_HMAC(keyStr, #keyStr, salt, #salt, 999, libcrypto.EVP_sha512(), 32, derivedKey)
                        if res == 1 then
                            local decrypt_res, decrypt_err = pcall(function()
                                local ctx = libcrypto.EVP_CIPHER_CTX_new()
                                if ctx ~= nil then
                                    libcrypto.EVP_DecryptInit_ex(ctx, libcrypto.EVP_aes_256_cbc(), nil, derivedKey, iv)
                                    local out = ffi.new("unsigned char[?]", #cipherbin + 32)
                                    local outl = ffi.new("int[1]")
                                    local outl2 = ffi.new("int[1]")
                                    libcrypto.EVP_DecryptUpdate(ctx, out, outl, cipherbin, #cipherbin)
                                    if libcrypto.EVP_DecryptFinal_ex(ctx, out + outl[0], outl2) == 1 then
                                        content = ffi.string(out, outl[0] + outl2[0])
                                        decrypt_ok = true
                                        Debug.write("[haccbl] native decrypt successful! content len: " .. #content)
                                    end
                                    libcrypto.EVP_CIPHER_CTX_free(ctx)
                                end
                            end)
                        end
                    end
                end

                if not decrypt_ok then
                    Debug.write("[haccbl] Falling back to pure lua pbkdf2 and aes")
                    local fallback_ok, fallback_err = pcall(function()
                        local bit = require("bit")
                        local current_dir = debug.getinfo(1, "S").source:match("^@?(.*[/\\])")
                        if not string.find(package.path, "aeslua[/\\]src[/\\]%?%.lua", 1, true) then
                            package.path = package.path .. ";" .. current_dir .. "aeslua/src/?.lua;" .. current_dir .. "?.lua"
                        end
                        
                        local sha2 = require("sha2")
                        local aeslua_main = require("aeslua")
                        local ciphermode = require("aeslua.ciphermode")
                        local util = require("aeslua.util")
                        
                        local hLen = 64
                        local l = math.ceil(32 / hLen)
                        local derivedKeyStr = ""
                        
                        for i = 1, l do
                            local i_bin = string.char(
                                bit.rshift(i, 24) % 256,
                                bit.rshift(i, 16) % 256,
                                bit.rshift(i, 8) % 256,
                                i % 256
                            )
                            
                            local u_input = salt .. i_bin
                            local u_in_hex = sha2.hmac(sha2.sha512, keyStr, u_input)
                            local u_in_bin = hex2bin(u_in_hex)
                            local t_bin = u_in_bin
                            
                            for j = 2, 999 do
                                u_in_hex = sha2.hmac(sha2.sha512, keyStr, u_in_bin)
                                u_in_bin = hex2bin(u_in_hex)
                                
                                local new_t_bin = {}
                                for k = 1, 64 do
                                    new_t_bin[k] = string.char(bit.bxor(string.byte(t_bin, k), string.byte(u_in_bin, k)))
                                end
                                t_bin = table.concat(new_t_bin)
                            end
                            
                            derivedKeyStr = derivedKeyStr .. t_bin
                        end
                        
                        local derivedKeyStr32 = string.sub(derivedKeyStr, 1, 32)
                        local key_table = {string.byte(derivedKeyStr32, 1, 32)}
                        local iv_table = {string.byte(iv, 1, 16)}
                        
                        local plain = ciphermode.decryptString(key_table, cipherbin, ciphermode.decryptCBC, iv_table)
                        
                        local function pkcs7_unpad(data)
                            if #data == 0 then return nil end
                            local pad_len = string.byte(data, #data)
                            if pad_len > 0 and pad_len <= 16 then
                                return string.sub(data, 1, #data - pad_len)
                            end
                            return data
                        end
                        
                        local unpadded = pkcs7_unpad(plain)
                        if unpadded then
                            content = unpadded
                            decrypt_ok = true
                        end
                    end)
                    if fallback_ok and decrypt_ok then
                        Debug.write("[haccbl] pure lua pbkdf2 and aes success! content len: " .. #content)
                    else
                        Debug.write("[haccbl] pure lua pbkdf2 or aes failed: " .. tostring(fallback_err))
                    end
                end
            else
                Debug.write("[haccbl] status is false or ffi is nil: status=" .. tostring(status))
            end
        end

        if content:find("InitMangaEncryptedChapter", 1, true) then
            return nil, "Hắc Ám Chi Các đang mã hóa ảnh chương, plugin chưa giải mã được nguồn này (hoặc thiếu thư viện)."
        end
    end

    for image_tag in content:gmatch("(<img[^>]*>)") do
        local src = Util.getAttribute(image_tag, "data-src")
            or Util.getAttribute(image_tag, "data-lazy-src")
            or Util.getAttribute(image_tag, "src")
        local url = Util.absoluteUrl(self.base_url, src)
        if url
                and not url:find("cropped%-icon", 1, false)
                and not url:find("avatar", 1, true)
                and not url:find("gravatar", 1, true) then
            if url:find("%.avif", 1, true) then
                url = url:gsub("^https?://", "https://i0.wp.com/") .. "?strip=info"
            end
            table.insert(images, { urls = { url } })
        end
    end

    if #images == 0 then
        return nil, "Không tìm thấy ảnh của chương"
    end

    return {
        title = chapter.title,
        images = images,
        url = chapter.url,
        referer = self.base_url .. "/",
        kind = self.kind,
    }
end

function Source:getChapter(chapter)
    local html, err = Http:get(chapter.url, requestHeaders())
    if not html then
        return nil, err
    end
    return self:parseChapter(html, chapter)
end

return Source
