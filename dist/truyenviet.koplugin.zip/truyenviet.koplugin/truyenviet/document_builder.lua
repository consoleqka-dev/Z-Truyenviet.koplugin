local Archiver = require("ffi/archiver")
local Http = require("truyenviet/http_client")
local ImageUtils = require("truyenviet/image_utils")
local Storage = require("truyenviet/storage")
local Util = require("truyenviet/helpers")
local lfs = require("libs/libkoreader-lfs")
local socket = require("socket")
local Debug = require("truyenviet/debugger")

local DocumentBuilder = {}

local function replaceFile(temp_path, final_path)
    local ok, err = os.rename(temp_path, final_path)
    if not ok then
        -- Fallback to copy and delete if cross-device (e.g. from /tmp to eMMC)
        local fin, fin_err = io.open(temp_path, "rb")
        if not fin then
            os.remove(temp_path)
            return nil, fin_err
        end
        local data = fin:read("*a")
        fin:close()
        
        local fout, fout_err = io.open(final_path, "wb")
        if not fout then
            os.remove(temp_path)
            return nil, fout_err
        end
        fout:write(data)
        fout:close()
        os.remove(temp_path)
    end
    return final_path
end

function DocumentBuilder:getTempPath(source, story, chapter)
    if lfs.attributes("/tmp", "mode") == "directory" then
        local extension = source.kind == "comic" and ".cbz" or ".html"
        local key = tostring(chapter.url or chapter.title):gsub("[^%w]", "")
        if #key > 40 then key = key:sub(-40) end
        return "/tmp/truyenviet_read_" .. key .. extension
    end
    return nil
end

function DocumentBuilder:getExistingPath(source, story, chapter, is_temp)
    local path = Storage:getChapterPath(source, story, chapter)
    if lfs.attributes(path, "mode") == "file" then
        return path
    end
    
    if is_temp then
        local temp_path = self:getTempPath(source, story, chapter)
        if temp_path and lfs.attributes(temp_path, "mode") == "file" then
            return temp_path
        end
    end
end

function DocumentBuilder:buildText(source, story, chapter, payload, is_temp)
    local path
    if is_temp then
        path = self:getTempPath(source, story, chapter) or Storage:getChapterPath(source, story, chapter)
    else
        path = Storage:getChapterPath(source, story, chapter)
    end
    local temp_path = path .. ".part"
    if lfs.attributes("/tmp", "mode") == "directory" then
        temp_path = "/tmp/truyenviet_temp_" .. os.time() .. "_" .. tostring(math.random(1000, 9999)) .. ".part"
    end
    local file, err = io.open(temp_path, "wb")
    if not file then
        return nil, err
    end

    local title = payload.title or chapter.title
    local html = string.format([[
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>%s</title>
  <style>
    @font-face {
      font-family: 'BeVietnamPro';
      src: url('BeVietnamPro-Regular.ttf');
    }
    html, body, article, div {
      margin-left: 0 !important;
      margin-right: 0 !important;
      padding-left: 0 !important;
      padding-right: 0 !important;
      font-family: 'BeVietnamPro', 'Be Vietnam Pro', sans-serif !important;
      line-height: 1.6;
      text-align: justify;
      word-wrap: break-word;
    }
    h1 {
      font-size: 1.35em;
      line-height: 1.3;
      text-align: center;
      margin: 0.8em 0 0.4em 0;
    }
    .source {
      color: #666;
      font-size: 0.85em;
      text-align: center;
      margin-bottom: 0.8em;
    }
    p {
      margin-left: 0 !important;
      margin-right: 0 !important;
      margin-top: 0.6em !important;
      margin-bottom: 0.6em !important;
      padding-left: 0 !important;
      padding-right: 0 !important;
      text-indent: 1.5em !important;
      line-height: 1.6 !important;
    }
    img {
      height: auto;
      max-width: 100%%;
      display: block;
      margin: 0.5em auto;
    }
  </style>
</head>
<body>
  <h1>%s</h1>
  <p class="source">%s</p>
  <hr/>
  <article>%s</article>
</body>
</html>
]],
        Util.escapeHtml(title),
        Util.escapeHtml(title),
        Util.escapeHtml(payload.url or chapter.url),
        Util.cleanChapterHtml(payload.content or "")
    )

    local ok, write_err = file:write(html)
    file:close()
    if not ok then
        os.remove(temp_path)
        return nil, write_err
    end

    return replaceFile(temp_path, path)
end

local function downloadImage(image, referer)
    local last_error
    for _, url in ipairs(image.urls) do
        local content, err, headers = Http:get(url, {
            ["Referer"] = referer,
            ["Accept"] = "image/avif,image/webp,image/apng,image/*,*/*;q=0.8",
        })
        if content then
            return content, headers, url
        end
        last_error = err
    end
    return nil, last_error
end

local function downloadImageWithRetry(image, referer, max_retries)
    max_retries = max_retries or 3
    local last_error
    local delay_ms = 500
    
    for attempt = 1, max_retries do
        for _, url in ipairs(image.urls) do
            local content, err, headers = Http:get(url, {
                ["Referer"] = referer,
                ["Accept"] = "image/avif,image/webp,image/apng,image/*,*/*;q=0.8",
            })
            if content then
                return content, headers, url
            end
            last_error = err
        end
        
        if attempt < max_retries then
            socket.sleep(delay_ms / 1000)
            delay_ms = math.min(delay_ms * 2, 5000)
        end
    end
    return nil, last_error
end

function DocumentBuilder:buildComic(source, story, chapter, payload, is_temp)
    local path
    if is_temp then
        path = self:getTempPath(source, story, chapter) or Storage:getChapterPath(source, story, chapter)
    else
        path = Storage:getChapterPath(source, story, chapter)
    end
    local temp_path = path .. ".part"
    if lfs.attributes("/tmp", "mode") == "directory" then
        temp_path = "/tmp/truyenviet_temp_" .. os.time() .. "_" .. tostring(math.random(1000, 9999)) .. ".part"
    end
    os.remove(temp_path)

    local archive = Archiver.Writer:new()
    if not archive:open(temp_path, "zip") then
        return nil, archive.err or "Không thể tạo tệp CBZ"
    end
    archive:setZipCompression("store")

    local ok, result, result_err = pcall(function()
        local copas = require("copas")
        local active_downloads = 0
        local max_concurrent = 4
        local has_error = false
        local archive_err = nil
        local failed_images = {}
        local downloaded_count = 0
        local max_retries = 3

        local chapter_start = os.time()
        local chapter_timeout = source.id == "dualeo" and 120 or 300

        -- Không chèn ảnh bìa truyện làm trang đầu: bìa từ nguồn thường chỉ là ảnh nhỏ
        -- (TruyenQQ 190x247) nên bị phóng mờ khi KOReader hiển thị cả trang.
        for index, image in ipairs(payload.images) do
            if os.time() - chapter_start > chapter_timeout then
                has_error = true
                archive_err = "Timeout downloading chapter after " .. tostring(chapter_timeout) .. "s"
                Debug.write("DocumentBuilder:buildComic aborting chapter due to overall timeout")
                break
            end
            while active_downloads >= max_concurrent do
                copas.step()
            end
            
            if has_error then break end

            active_downloads = active_downloads + 1
            copas.addthread(function()
                local last_error
                local content, headers, final_url
                
                for attempt = 1, max_retries do
                    for _, url in ipairs(image.urls) do
                        local req_headers = (type(source.getImageHeaders) == "function" and source:getImageHeaders()) or {}
                        if not req_headers["Referer"] then req_headers["Referer"] = payload.referer or "" end
                        if not req_headers["Accept"] then req_headers["Accept"] = "image/avif,image/webp,image/apng,image/*,*/*;q=0.8" end
                        req_headers["Connection"] = req_headers["Connection"] or "keep-alive"
                        req_headers["Accept-Language"] = req_headers["Accept-Language"] or "vi-VN,vi;q=0.9,en;q=0.7"

                        local c, e, h = Http:requestAsync("GET", url, nil, req_headers, { timeout = source.id == "dualeo" and 12 or 20 })
                        if c then
                            content = c
                            headers = h
                            final_url = url
                            break
                        end
                        last_error = e
                        Debug.write("DocumentBuilder:buildComic download failed idx=" .. tostring(index) .. " url=" .. tostring(url) .. " err=" .. tostring(e))
                    end
                    
                    if content then
                        break
                    end
                    
                    if attempt < max_retries then
                        socket.sleep(0.2 * attempt)
                    end
                end

                if content and ImageUtils:isSupported(headers, content) then
                    local extension = ImageUtils:detectExtension(headers, content, final_url)
                    local entry_name = string.format("%04d.%s", index, extension)
                    if not archive:addFileFromMemory(entry_name, content, os.time()) then
                        has_error = true
                        archive_err = archive.err or ("Không thể ghi " .. entry_name)
                    else
                        downloaded_count = downloaded_count + 1
                    end
                else
                    Debug.write("DocumentBuilder:buildComic unsupported/failed idx=" .. tostring(index) .. " final_url=" .. tostring(final_url) .. " last_error=" .. tostring(last_error))
                    table.insert(failed_images, index)
                    -- Use blank 1x1 PNG to prevent missing pages
                    archive:addFileFromMemory(string.format("%04d.png", index), "\137PNG\r\n\26\n\0\0\0\13IHDR\0\0\0\1\0\0\0\1\8\6\0\0\0\31\21\196\137\0\0\0\10IDATx\156c\0\1\0\0\5\0\1\13\10\2db\0\0\0\0IEND\174B`\130", os.time())
                end

                active_downloads = active_downloads - 1
            end)
        end

        while active_downloads > 0 do
            copas.step()
        end

        if has_error then
            error(archive_err)
        end
        
        if downloaded_count == 0 and #payload.images > 0 then
            error("Lỗi: Không thể tải hình ảnh hợp lệ của chương truyện tranh")
        end
        
        if #failed_images > 0 then
            Debug.write(string.format("DocumentBuilder:buildComic warning: failed %d images", #failed_images))
        end
        
        return true
    end)

    archive:close()
    collectgarbage()
    collectgarbage()

    if not ok then
        os.remove(temp_path)
        return nil, tostring(result)
    end
    if not result then
        os.remove(temp_path)
        return nil, result_err
    end

    return replaceFile(temp_path, path)
end

function DocumentBuilder:build(source, story, chapter, payload, force, is_temp)
    if type(payload) == "string" then
        payload = { content = payload }
    end
    if not force then
        local existing = self:getExistingPath(source, story, chapter, is_temp)
        if existing then
            return existing
        end
    end
    if source.kind == "comic" then
        return self:buildComic(source, story, chapter, payload, is_temp)
    end
    return self:buildText(source, story, chapter, payload, is_temp)
end

return DocumentBuilder
